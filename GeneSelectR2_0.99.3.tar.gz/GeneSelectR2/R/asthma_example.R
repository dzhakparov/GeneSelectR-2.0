#' Compact U-BIOPRED asthma expression example
#'
#' A deterministic subset of GEO GSE69683 containing 48 moderate and 48 severe
#' asthma samples and 300 genes. Measurements retain the prepared benchmark's
#' submitter-normalized log scale. The subset is for testing package usage and
#' is not suitable for reproducing the reported full-cohort benchmark AUC.
#'
#' @format A SummarizedExperiment with 300 gene rows and 96 sample columns.
#'   The log_expression assay contains numeric expression measurements.
#'   colData contains the severity factor, ordered moderate then severe.
#'   Sample identifiers are GEO accessions. metadata records the source,
#'   platform, expression scale and subset rule.
#' @source GEO accession GSE69683, platform GPL13158:
#'   \url{https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE69683}.
#'   Reconstruction code is in inst/scripts/prepare_asthma_example.R.
#' @usage data(asthma_example)
#' @examples
#' data(asthma_example)
#' dim(asthma_example)
#' table(SummarizedExperiment::colData(asthma_example)$severity)
"asthma_example"
