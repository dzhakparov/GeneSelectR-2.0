#' Run the predictive GeneSelectR 2.0 workflow
#'
#' Rank genes with repeated elastic-net inclusion and excluded-sample
#' contribution. Biological annotations are applied downstream and do not enter
#' the ranking.
#'
#' @param x A numeric matrix with samples in rows and named genes in columns,
#'   or a SummarizedExperiment with genes in rows and samples in columns.
#' @param outcome A two-level factor for a matrix input, or the name of a
#'   colData column for a SummarizedExperiment. The second level is positive.
#' @param assay_name Name of the assay containing normalized expression.
#' @param n_genes Number of genes to return from the ranking.
#' @param alpha Elastic-net mixing values compared using internal AUC.
#' @param B Number of repeated model fits for each alpha.
#' @param permutations Number of shuffled-outcome references.
#' @param null_B Number of model fits per shuffled outcome.
#' @param k_folds Number of stratified folds. The benchmark used five.
#' @param seed Random seed, restored on return.
#' @param workers Number of fitting workers. Default one.
#'
#' @return A geneselectr2_result containing gene_scores, parameters, cv_results
#'   and stability, with additional selected_genes and alpha_comparison fields.
#'   selected_genes contains the first n_genes gene names from the ranking.
#' @details Input must already be normalized. Select variable genes and fit
#'   preprocessing operations using training samples only. All genes receive
#'   equal penalty weights. The selected alpha has the greatest mean internal
#'   AUC; ties retain the first alpha supplied. The component ratios are ranking
#'   quantities and provide no probabilities, p-values or FDR guarantee.
#' @examples
#' data(asthma_example)
#' fit <- select_genes(asthma_example, "severity",
#'     n_genes = 10,
#'     alpha = 0.5, B = 2, permutations = 1, null_B = 2
#' )
#' head(fit$selected_genes)
#' @export
select_genes <- function(x, outcome, assay_name = "log_expression",
                            n_genes = 20L, alpha = c(0.5, 1), B = 50L,
                            permutations = 20L, null_B = 20L, k_folds = 5L,
                            seed = 123L, workers = 1L) {
    if (methods::is(x, "SummarizedExperiment")) {
        if (!is.character(outcome) || length(outcome) != 1L ||
            !outcome %in% names(SummarizedExperiment::colData(x))) {
            stop("outcome must name a colData column")
        }
        y <- SummarizedExperiment::colData(x)[[outcome]]
        if (!assay_name %in% SummarizedExperiment::assayNames(x)) {
            stop("assay_name is absent from the experiment")
        }
        X <- t(as.matrix(SummarizedExperiment::assay(x, assay_name)))
    } else {
        X <- x
        y <- outcome
    }
    if (!is.matrix(X) || !is.numeric(X) || is.null(colnames(X)) ||
        anyNA(colnames(X)) || any(!nzchar(colnames(X))) ||
        anyDuplicated(colnames(X))) {
        stop("Expression must be numeric with unique, non-empty gene names")
    }
    if (!is.factor(y) || nlevels(y) != 2L || anyNA(y) ||
        length(y) != nrow(X)) {
        stop("outcome must be a two-level factor aligned with samples")
    }
    if (length(n_genes) != 1L || !is.finite(n_genes) ||
        n_genes < 1 || n_genes != as.integer(n_genes) ||
        n_genes > ncol(X)) {
        stop("n_genes must be an integer between one and the gene count")
    }
    if (!is.numeric(alpha) || !length(alpha) || anyNA(alpha) ||
        any(!is.finite(alpha)) || any(alpha < 0 | alpha > 1)) {
        stop("alpha must contain finite values between zero and one")
    }
    for (value in list(B, permutations, null_B, k_folds, workers)) {
        if (length(value) != 1L || !is.numeric(value) ||
            !is.finite(value) || value < 1 || value != as.integer(value)) {
            stop("Fit counts and workers must be positive integers")
        }
    }
    fits <- lapply(alpha, function(a) {
        geneselectr2_fit(
            X, y,
            B = B, alpha = a, k_folds = k_folds,
            permutations = permutations, null_B = null_B,
            random_seed = seed, workers = workers, verbose = FALSE
        )
    })
    auc <- vapply(fits, function(fit) fit$cv_results$mean_auc, numeric(1))
    if (any(!is.finite(auc))) {
        stop("Internal AUC unavailable for at least one alpha")
    }
    fit <- fits[[which.max(auc)]]
    fit$selected_genes <- utils::head(fit$gene_scores$gene, n_genes)
    fit$alpha_comparison <- data.frame(alpha = alpha, internal_auc = auc)
    fit
}
